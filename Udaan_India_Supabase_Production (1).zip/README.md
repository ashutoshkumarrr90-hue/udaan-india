# Udaan India — Supabase Production Project

## What is included
- Next.js App Router
- Supabase Auth
- PostgreSQL database
- Row Level Security
- Student profiles
- Opportunities database
- Saved opportunities
- Application tracker
- Help requests
- Admin roles
- Secure admin page
- Scholarship finder filters

## Setup
1. Create a Supabase project.
2. Open SQL Editor and run `supabase/schema.sql`.
3. Copy `.env.example` to `.env.local`.
4. Add your Supabase URL and anon key.
5. Run `npm install`.
6. Run `npm run dev`.

## Make yourself an admin
After creating your account, run this in Supabase SQL Editor:

```sql
insert into public.admins (user_id, role)
select id, 'super_admin' from auth.users where email = 'YOUR_EMAIL';
```

## Security
- Never store Aadhaar numbers, OTPs, bank passwords, or government portal passwords.
- Opportunity application links should point to official providers.
- Verify every scholarship before publishing.
