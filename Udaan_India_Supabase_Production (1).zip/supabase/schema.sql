-- Udaan India database schema
create extension if not exists "uuid-ossp";

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text,
 email text,
 phone text,
 education_level text,
 course text,
 state text,
 district text,
 category text,
 income_range text,
 academic_percentage numeric,
 created_at timestamptz default now(),
 updated_at timestamptz default now()
);

create table if not exists public.admins (
 id uuid primary key default gen_random_uuid(),
 user_id uuid unique references auth.users(id) on delete cascade,
 role text not null default 'editor' check (role in ('super_admin','admin','editor','support')),
 created_at timestamptz default now()
);

create table if not exists public.opportunities (
 id uuid primary key default gen_random_uuid(),
 title text not null,
 slug text unique not null,
 provider_name text not null,
 category text not null,
 short_description text,
 description text,
 eligibility text,
 benefits text,
 required_documents text,
 application_steps text,
 official_url text,
 application_url text,
 deadline text,
 status text not null default 'active' check (status in ('draft','active','expired','archived')),
 verification_status text not null default 'pending' check (verification_status in ('verified','pending','needs_update')),
 last_verified_at timestamptz,
 created_at timestamptz default now(),
 updated_at timestamptz default now()
);

create table if not exists public.saved_opportunities (
 id uuid primary key default gen_random_uuid(),
 user_id uuid references auth.users(id) on delete cascade not null,
 opportunity_id uuid references public.opportunities(id) on delete cascade not null,
 created_at timestamptz default now(),
 unique(user_id,opportunity_id)
);

create table if not exists public.application_tracking (
 id uuid primary key default gen_random_uuid(),
 user_id uuid references auth.users(id) on delete cascade not null,
 opportunity_id uuid references public.opportunities(id) on delete cascade not null,
 status text not null default 'interested' check (status in ('interested','preparing_documents','applied','under_verification','approved','not_selected')),
 notes text,
 applied_date date,
 updated_at timestamptz default now(),
 unique(user_id,opportunity_id)
);

create table if not exists public.help_requests (
 id uuid primary key default gen_random_uuid(),
 user_id uuid references auth.users(id) on delete set null,
 category text,
 subject text not null,
 message text not null,
 status text not null default 'new' check (status in ('new','in_progress','resolved','closed')),
 admin_notes text,
 created_at timestamptz default now(),
 updated_at timestamptz default now()
);

-- Automatic profile creation
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
 insert into public.profiles (id,full_name,email)
 values (new.id,new.raw_user_meta_data->>'full_name',new.email);
 return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Admin helper
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.admins where user_id=auth.uid());
$$;

alter table public.profiles enable row level security;
alter table public.admins enable row level security;
alter table public.opportunities enable row level security;
alter table public.saved_opportunities enable row level security;
alter table public.application_tracking enable row level security;
alter table public.help_requests enable row level security;

create policy "public can view active opportunities" on public.opportunities
for select using (status='active' or public.is_admin());
create policy "admins manage opportunities" on public.opportunities
for all using (public.is_admin()) with check (public.is_admin());

create policy "users view own profile" on public.profiles for select using (auth.uid()=id or public.is_admin());
create policy "users update own profile" on public.profiles for update using (auth.uid()=id) with check (auth.uid()=id);

create policy "users manage own saves" on public.saved_opportunities
for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "users manage own applications" on public.application_tracking
for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "users create help requests" on public.help_requests
for insert with check (auth.uid()=user_id);
create policy "users view own help requests" on public.help_requests
for select using (auth.uid()=user_id or public.is_admin());
create policy "admins manage help requests" on public.help_requests
for all using (public.is_admin()) with check (public.is_admin());
create policy "users can view own admin row" on public.admins
for select using (auth.uid()=user_id);

-- Never store Aadhaar numbers, OTPs, government portal passwords or bank passwords.
